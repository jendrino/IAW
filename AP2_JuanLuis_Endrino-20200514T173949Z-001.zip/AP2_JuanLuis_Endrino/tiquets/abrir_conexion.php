<?php 
	$host = "localhost";
	$usuariodb = "root";
	$clavedb = "Barcelona1.";
	$basededatos = "tickets";
	$tabla_db1 = "ticket";
	
	$conexion = new mysqli($host,$usuariodb,$clavedb,$basededatos);

	if ($conexion->connect_errno) {
	    echo "Nuestro sitio experimenta fallos....";
	    exit();
	}

?>
