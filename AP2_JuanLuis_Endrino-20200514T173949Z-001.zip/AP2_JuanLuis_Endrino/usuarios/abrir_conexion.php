<?php 
	$host = "localhost";
	$usuariodb = "root";
	$clavedb = "Barcelona1.";
	$basededatos = "tickets";

	
	$conexion = new mysqli($host,$usuariodb,$clavedb,$basededatos);

	if ($conexion->connect_errno) {
	    echo "Nuestro sitio experimenta fallos....";
	    exit();
	}

?>
