<!DOCTYPE html>
<html>
<head>
	<title>AP2.Creació d'una aplicació d'administració d'incidències (Ticketing)</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
	<h2>TABLA DE TICKETS</h2>
	<?php
	$link = mysqli_connect ("localhost","root","Barcelona1.","tickets");
	if ($link === false){
		die("ERROR ".mysqli_connect_error());
	}
	$sql = "select * from ticket where estado = 'Cerrada'";
	if($result = mysqli_query($link, $sql)){
		if(mysqli_num_rows($result) > 0){
			echo "<table border='1'>";
			echo "<tr>";
				echo "<th>id_tic</th>";
				echo "<th>nom_tic</th>";
				echo "<th>categoria</th>";
				echo "<th>renponsable</th>";
				echo "<th>estado</th>";
			echo "</tr>";
			while($row = mysqli_fetch_array($result)){
				echo "<tr>";
					echo "<td>" . $row['id_tic'] . "</td>";
					echo "<td>" . $row['nom_tic'] . "</td>";
					echo "<td>" . $row['categoria'] . "</td>";
					echo "<td>" . $row['renponsable'] . "</td>";
					echo "<td>" . $row['estado'] . "</td>";
				echo "</tr>";
				
				$file=fopen("historico.txt","w");
				fwrite($file,$row['id_tic']."  ".$row['nom_tic']."   ".$row['categoria']."   ".$row['renponsable']."  ".$row['estado']."&nbsp");
				
			}
			fclose($file);
			echo "</table>";
			 mysqli_free_result($result);
		}
	}
	?>
	
	<p>En la misma carpeta se ha descardo un fichero con la misma informacion que se muestra en esta pagina</p>
	
	<input type="button" value="Descarga">
	</p>
	<a href="../ticketing/dashboard.php" class="active">Dashboard</a>
</body>
</html>

