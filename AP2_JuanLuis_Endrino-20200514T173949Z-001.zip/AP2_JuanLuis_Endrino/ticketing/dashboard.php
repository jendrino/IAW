<!DOCTYPE html>
<html>
<head>
	<title>AP2.Creació d'una aplicació d'administració d'incidències (Ticketing)</title>
        <link rel="stylesheet" href="css/styles.css">
</head>
<body>
        <nav>
            <ul class="especial">
                <table>
                    <th><li><a href="../AP2/cerrar_session.php" class="active">Cerrar Sesion</a>
                    <th><li> <a href="../tiquets/registro.php">Incidencias</a>
                    <th><li><a href="../ticketing/historico.php">Historico</a>
                    <th><li><a href="../usuarios/registro.php">Admin</a>
                </table>
            </ul>
        </nav>
	
	<h2>TICKETS TOTALES</h2>
	<?php
		session_start();
        $usuario=$_POST['usuario'];
        $clave=$_POST['clave'];

        //conectar Ia la base de datos
        $conexion=mysqli_connect("localhost", "root", "Barcelona1.", "tickets");
        $query = "SELECT count(*) as totalticketabiertos from ticket";
        $res=mysqli_query($conexion, $query);
        $data=mysqli_fetch_assoc($res);

        echo "Tickets Totales: ".$data['totalticketabiertos']
        ?>
	<h2>TICKETS ABIERTOS</h2>
	<?php
		session_start();
        $usuario=$_POST['usuario'];
        $clave=$_POST['clave'];

        //conectar Ia la base de datos
        $conexion=mysqli_connect("localhost", "root", "Barcelona1.", "tickets");
        $query = "SELECT count(*) as totalticketabiertos from ticket where estado='Abierta'";
        $res=mysqli_query($conexion, $query);
        $data=mysqli_fetch_assoc($res);

        echo "Tickets Abiertos: ".$data['totalticketabiertos']
        ?>
	<h2>TICKETS CERRADOS</h2>
	<?php
		session_start();
        $usuario=$_POST['usuario'];
        $clave=$_POST['clave'];

        //conectar Ia la base de datos
        $conexion=mysqli_connect("localhost", "root", "Barcelona1.", "tickets");
        $query = "SELECT count(*) as totalticketabiertos from ticket where estado='Cerrada'";
        $res=mysqli_query($conexion, $query);
        $data=mysqli_fetch_assoc($res);

        echo "Tickets Cerrados: ".$data['totalticketabiertos']
        ?>
        <h2>CATEGORIA DE TICKETS</h2>
	<?php
		session_start();
        $usuario=$_POST['usuario'];
        $clave=$_POST['clave'];

        //conectar Ia la base de datos
        $conexion=mysqli_connect("localhost", "root", "Barcelona1.", "tickets");
        $query = "SELECT categoria as totalticketabiertos from ticket";
        $res=mysqli_query($conexion, $query);
        $data=mysqli_fetch_assoc($res);

        echo "Categoria: ".$data['totalticketabiertos']
        ?>
        <h2>PORCETAJE DE TICKETS ABIERTOS</h2>
        <?php
        $conexion=mysqli_connect("localhost", "root", "Barcelona1.", "tickets");

		//% incidencias pendientes
		$query = "SELECT count(*)/(SELECT count(*) from ticket)* 100 as percentage from ticket where estado='Abierta'";
		$res=mysqli_query($conexion, $query);
		$data=mysqli_fetch_assoc($res);
		echo "Porcentaje Abiertos: ".$data['percentage']
		?>
		<h2>TICKETS POR USUARIOS</h2>
		<?php
		$conn = mysqli_connect("localhost", "root", "Barcelona1.", "tickets");
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT renponsable,count(*)/(SELECT count(*) from ticket)* 100 as percentage from ticket group by renponsable";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["renponsable"]. " ".$row["percentage"] . "<br>";
        }
        echo "</table>";
        } else { echo "0 results"; }
        $conn->close();
		?>
	
	<div id="chart_div" style="width: 400px; height: 500px;"></div>
</body>
</html>
